import sys
sys.path.append(__package__)

from .tolk import *

